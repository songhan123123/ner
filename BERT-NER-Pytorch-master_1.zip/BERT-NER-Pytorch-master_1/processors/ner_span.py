""" Named entity recognition fine-tuning: utilities to work with CoNLL-2003 task. """
import ast

import torch
import logging
import os
import copy
import json

from transformers import BertTokenizer

from .utils_ner import DataProcessor,get_entities
logger = logging.getLogger(__name__)

def return_start_end(dicc):
    labell = dicc['label']
    for key in labell:
        spiic = labell[key]
        for keyy in spiic:
            spiicc = spiic[keyy]
            start = spiicc[0][0]
            end = spiicc[0][1]

    return start,end

def guid_find(inputfile, guid):#filename为写入CSV文件的路径，data为要写入数据列表.
    '''

    Args:
        inputfile: train4.json或者dev4.json文件
        guid:这个存进来的是"train-38"的格式
        目标就是找到guid对应的数据，再把start和end取出来用

    Returns:

    '''
    file = open(inputfile,'r',encoding='utf-8')
    guidd = []
    guidd = guid.split('-')
    num_guid = int(guidd[1])
    files = file.readlines()
    #print('lennnn',len(files))
    #print('files',files)
    aim_dict = files[num_guid]
    #print('aim_dict1111',aim_dict)
    aim_dict = ast.literal_eval(aim_dict)
    #print('aim_dict222',aim_dict)
    '''
    {"text": "Anamnesis Paciente varón de 63 años", "label": {"HUMAN": {"Paciente varón": [[0, 1]]}}}
    '''
    start, end = return_start_end(aim_dict)


    #print("startt",start,'endd', end)
    return start, end


class InputExample(object):
    """A single training/test example for token classification."""
    def __init__(self, guid, text_a, subject):
        self.guid = guid
        self.text_a = text_a
        self.subject = subject
    def __repr__(self):
        return str(self.to_json_string())
    def to_dict(self):
        """Serializes this instance to a Python dictionary."""
        output = copy.deepcopy(self.__dict__)
        return output
    def to_json_string(self):
        """Serializes this instance to a JSON string."""
        return json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n"#json.dumps()用于将dict类型的数据转成str

class InputFeature(object):
    """A single set of features of data."""

    def __init__(self, input_ids, input_mask, input_len, segment_ids, start_ids,end_ids, subjects):
        self.input_ids = input_ids
        self.input_mask = input_mask
        self.segment_ids = segment_ids
        self.start_ids = start_ids
        self.input_len = input_len
        self.end_ids = end_ids
        self.subjects = subjects

    def __repr__(self):
        return str(self.to_json_string())

    def to_dict(self):
        """Serializes this instance to a Python dictionary."""
        output = copy.deepcopy(self.__dict__)
        return output

    def to_json_string(self):
        """Serializes this instance to a JSON string."""
        return json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n"

def collate_fn(batch):
    """
    batch should be a list of (sequence, target, length) tuples...
    Returns a padded tensor of sequences sorted from longest to shortest,
    """
    all_input_ids, all_input_mask, all_segment_ids, all_start_ids,all_end_ids,all_lens = map(torch.stack, zip(*batch))#stack(inputs, dim=) :沿着一个新维度对输入张量序列进行连接。 序列中所有的张量都应该为相同形状。
    max_len = max(all_lens).item()
    all_input_ids = all_input_ids[:, :max_len]
    all_input_mask = all_input_mask[:, :max_len]
    all_segment_ids = all_segment_ids[:, :max_len]
    all_start_ids = all_start_ids[:, :max_len]
    all_end_ids = all_end_ids[:, :max_len]
    return all_input_ids, all_input_mask, all_segment_ids, all_start_ids,all_end_ids,all_lens

def convert_examples_to_features(examples,label_list,max_seq_length,tokenizer,
                                 cls_token_at_end=False,cls_token="[CLS]",cls_token_segment_id=1,
                                 sep_token="[SEP]",pad_on_left=False,pad_token=0,pad_token_segment_id=0,
                                 sequence_a_segment_id=0,mask_padding_with_zero=True,
                                 inputfile = r'/content/drive/MyDrive/BERT-NER-Pytorch-master_1/datasets/cluener/train4.json'):
    """ Loads a data file into a list of `InputBatch`s
        `cls_token_at_end` define the location of the CLS token:
            - False (Default, BERT/XLM pattern): [CLS] + A + [SEP] + B + [SEP]
            - True (XLNet/GPT pattern): A + [SEP] + B + [SEP] + [CLS]
        `cls_token_segment_id` define the segment id associated to the CLS token (0 for BERT, 2 for XLNet)
    """
    label2id = {label: i for i, label in enumerate(label_list)}
    features = []
    for (ex_index, example) in enumerate(examples):
        ##print('examplessssssssssss', examples)
        if ex_index % 10000 == 0:
            logger.info("Writing example %d of %d", ex_index, len(examples))
        #print('exampleeeeeeeeeee',example)
        guidd = example.guid
        textlist = example.text_a
        ##print("textlistttttttttttttttt______",textlist)
        subjects = example.subject
        ##print("subjectssssssssssss",subjects)
        if isinstance(textlist,list):
            ##print('textlistsuyannnnnnnnnnnnn',textlist)
            textlist = " ".join(textlist)
        ##print('textlisttttttttttttttt',textlist)
        tokens = tokenizer.tokenize(textlist)
        #print("tokensssssssssssssssssss",tokens)
        start_ids = [0] * len(tokens)
        end_ids = [0] * len(tokens)
        subjects_id = []
        ##print('subjectsssssssssss',subjects)
        for subject in subjects:
            #print('subjectttttttttttttttttttttttttttt',subject)
            label = subject[0]
            start = subject[1]
            end = subject[2]
            if end >len(end_ids)-1 or start >len(start_ids)-1:
                start, end = guid_find(inputfile, guidd)

            #print('starttttttttt',start)
            #print('endddddddddddd',end)
            #print('start_ids::::::',start_ids,'label2id::::',label2id)
            # #print('start_idsssss',start_ids)
            # #print('end_idsssss', end_ids)
            ##print("subjects_iddddddd:", subjects_id)
            start_ids[start] = label2id[label]
            end_ids[end] = label2id[label]
            subjects_id.append((label2id[label], start, end))
        # Account for [CLS] and [SEP] with "- 2".
        special_tokens_count = 2
        if len(tokens) > max_seq_length - special_tokens_count:
        #if len(tokens) > max_seq_length:
            #print('还是进不来吗？？？？？？？？？？？？')
            tokens = tokens[: (max_seq_length - special_tokens_count)]
            start_ids = start_ids[: (max_seq_length - special_tokens_count)]
            #    ##print('start_ids::::::!!!!', start_ids, 'label2id::::', label2id)
            end_ids = end_ids[: (max_seq_length - special_tokens_count)]
        # tokens = tokens[: max_seq_length]
        # start_ids = start_ids[: max_seq_length]
        #     ##print('start_ids::::::!!!!', start_ids, 'label2id::::', label2id)
        # end_ids = end_ids[: (max_seq_length)]
        # The convention in BERT is:
        # (a) For sequence pairs:
        #  tokens:   [CLS] is this jack ##son ##ville ? [SEP] no it is not . [SEP]
        #  type_ids:   0   0  0    0    0     0       0   0   1  1  1  1   1   1
        # (b) For single sequences:
        #  tokens:   [CLS] the dog is hairy . [SEP]
        #  type_ids:   0   0   0   0  0     0   0
        #
        # Where "type_ids" are used to indicate whether this is the first
        # sequence or the second sequence. The embedding vectors for `type=0` and
        # `type=1` were learned during pre-training and are added to the wordpiece
        # embedding vector (and position vector). This is not *strictly* necessary
        # since the [SEP] token unambiguously separates the sequences, but it makes
        # it easier for the model to learn the concept of sequences.
        #
        # For classification tasks, the first vector (corresponding to [CLS]) is
        # used as as the "sentence vector". Note that this only makes sense because
        # the entire model is fine-tuned.
        tokens += [sep_token]
        start_ids += [0]
        end_ids += [0]
        segment_ids = [sequence_a_segment_id] * len(tokens)
        if cls_token_at_end:
            tokens += [cls_token]
            start_ids += [0]
            end_ids += [0]
            segment_ids += [cls_token_segment_id]
        else:
            tokens = [cls_token] + tokens
            start_ids = [0]+ start_ids
            end_ids = [0]+ end_ids
            segment_ids = [cls_token_segment_id] + segment_ids

        input_ids = tokenizer.convert_tokens_to_ids(tokens)
        # The mask has 1 for real tokens and 0 for padding tokens. Only real
        # tokens are attended to.
        input_mask = [1 if mask_padding_with_zero else 0] * len(input_ids)
        input_len = len(input_ids)
        # Zero-pad up to the sequence length.
        padding_length = max_seq_length - len(input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            input_mask = ([0 if mask_padding_with_zero else 1] * padding_length) + input_mask
            segment_ids = ([pad_token_segment_id] * padding_length) + segment_ids
            start_ids = ([0] * padding_length) + start_ids
            end_ids = ([0] * padding_length) + end_ids
        else:
            input_ids += [pad_token] * padding_length
            input_mask += [0 if mask_padding_with_zero else 1] * padding_length
            segment_ids += [pad_token_segment_id] * padding_length
            start_ids += ([0] * padding_length)
            end_ids += ([0] * padding_length)

        assert len(input_ids) == max_seq_length
        assert len(input_mask) == max_seq_length
        assert len(segment_ids) == max_seq_length
        assert len(start_ids) == max_seq_length
        assert len(end_ids) == max_seq_length

        if ex_index < 3:
            logger.info("*** Example ***")
            logger.info("guid: %s", example.guid)
            logger.info("tokens: %s", " ".join([str(x) for x in tokens]))
            logger.info("input_ids: %s", " ".join([str(x) for x in input_ids]))
            logger.info("input_mask: %s", " ".join([str(x) for x in input_mask]))
            logger.info("segment_ids: %s", " ".join([str(x) for x in segment_ids]))
            logger.info("start_ids: %s" % " ".join([str(x) for x in start_ids]))
            logger.info("end_ids: %s" % " ".join([str(x) for x in end_ids]))

        features.append(InputFeature(input_ids=input_ids,
                                  input_mask=input_mask,
                                  segment_ids=segment_ids,
                                  start_ids=start_ids,
                                  end_ids=end_ids,
                                  subjects=subjects_id,
                                  input_len=input_len))
    return features

class CnerProcessor(DataProcessor):
    """Processor for the chinese ner data set."""

    def get_train_examples(self, data_dir):
        """See base class."""
        return self._create_examples(self._read_text(os.path.join(data_dir, "train.char.bmes")), "train")

    def get_dev_examples(self, data_dir):
        """See base class."""
        return self._create_examples(self._read_text(os.path.join(data_dir, "dev.char.bmes")), "dev")

    def get_test_examples(self, data_dir):
        """See base class."""
        return self._create_examples(self._read_text(os.path.join(data_dir, "test.char.bmes")), "test")

    def get_labels(self):
        """See base class."""
        return ["O", "CONT", "ORG","LOC",'EDU','NAME','PRO','RACE','TITLE']

    def _create_examples(self, lines, set_type):
        """Creates examples for the training and dev sets."""
        examples = []
        for (i, line) in enumerate(lines):
            if i == 0:
                continue
            guid = "%s-%s" % (set_type, i)
            text_a = line['words']
            labels = []
            for x in line['labels']:
                if 'M-' in x:
                    labels.append(x.replace('M-','I-'))
                elif 'E-' in x:
                    labels.append(x.replace('E-', 'I-'))
                else:
                    labels.append(x)
            subject = get_entities(labels,id2label=None,markup='bios')
            examples.append(InputExample(guid=guid, text_a=text_a, subject=subject))
        return examples

class CluenerProcessor(DataProcessor):
    """Processor for the chinese ner data set."""

    def get_train_examples(self, data_dir):
        """See base class."""
        return self._create_examples(self._read_json(os.path.join(data_dir, "train5.json")), "train")

    def get_dev_examples(self, data_dir):
        """See base class."""
        return self._create_examples(self._read_json(os.path.join(data_dir, "dev5.json")), "dev")

    def get_test_examples(self, data_dir):
        """See base class."""
        return self._create_examples(self._read_json(os.path.join(data_dir, "test7.json")), "test")

    def get_labels(self):
        """See base class."""
    #    return ["O", "address", "book","company",'game','government','movie','name','organization','position','scene']
        return ["O", 'HUMAN',"SPECIES"]
    def _create_examples(self, lines, set_type):
        """Creates examples for the training and dev sets."""
        examples = []
        for (i, line) in enumerate(lines):
            guid = "%s-%s" % (set_type, i)
            text_a = line['words']
            labels = line['labels']
            subject = get_entities(labels,id2label=None,markup='bios')
            examples.append(InputExample(guid=guid, text_a=text_a, subject=subject))
        return examples


def get_true_entities(bert_class, line, start, end):
    '''

    Args:
        bert_class: 输入的预训练模型
        line: 输入的句子
        start: 句子转换成的token起始位置
        end: 句子转换成的token结束位置

    Returns:返回一个句子中的实体

    '''
    tokenizer = BertTokenizer.from_pretrained(bert_class, do_lower_case=False)
    tokens12 = line.strip().split(' ')  # 按照空格进行分词
    subwords = list(map(tokenizer.tokenize, tokens12))
    subword_lengths = list(map(len, subwords))
    for i in range(1, len(subword_lengths)):
        subword_lengths[i] += subword_lengths[i - 1]
    tokens = tokenizer.tokenize(line)
    result = []
    for j in range(start, end + 1):
        print('j', j)
        token11 = tokens[j]
        print('tokens11', token11)
        for i in range(len(subword_lengths)):
            if j < subword_lengths[i] and j >= subword_lengths[i - 1] and token11 not in result:
                if token11 not in result:
                    print('resultttt', result)
                    result.append(tokens12[i])
    # result = list(set(result))
    result = sorted(list(set(result)), key=result.index)
    strt=''
    indexx = 0
    for resultt in result:
        indexx+=1
        strt+=resultt
        if indexx < len(result)-1:
            strt+=' '
    return strt

def get_idx(line, entity):
    '''

    Args:
        line: 输入的句子
        entity: 得到原句的实体

    Returns:该句子的起始和末尾偏移量

    '''
    return line.index(entity), line.index(entity)+len(entity)

def get_idx_fromfiles(filename, line, entity):
    '''

    Args:
        filename: 文件名
        line: 句子
        entity: 该句子中的实体

    Returns:返回该实体在一个文件中的位置

    '''
    start2, end2 = get_idx(line, entity)
    with open(filename, 'r', encoding='utf-8') as f:
        texx = f.read()
    line_start = texx.index(line)
    start3 = line_start+start2
    end3 = line_start+end2
    return start3, end3

ner_processors = {
    "cner": CnerProcessor,
    'cluener':CluenerProcessor
}


